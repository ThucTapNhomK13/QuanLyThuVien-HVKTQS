﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class ConnectStr
    {
        public static string conStr = @"Data Source=MRKCUONG\MKCUONG;Initial Catalog=QuanLyThuVienHVKTQS;Integrated Security=True";

        public static string HungCuongSQL = @"Data Source=MRKCUONG\MKCUONG;Initial Catalog=QuanLyThuVienHVKTQS;Integrated Security=True";
    }
}
