﻿namespace QuanLyThuVienHVKTQS
{
    partial class fMuonTraSach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnNLMuon = new System.Windows.Forms.Button();
            this.btnMuonSach = new System.Windows.Forms.Button();
            this.dtpNgayMuon = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.dtpHanMuon = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMSach = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtNVMuon = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNMMuon = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnTKMuon = new System.Windows.Forms.Button();
            this.txtTKMuon = new System.Windows.Forms.TextBox();
            this.dgvDSMuon = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnNLTra = new System.Windows.Forms.Button();
            this.btnTraSach = new System.Windows.Forms.Button();
            this.dtpNgayTra = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.txtNVTra = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtTSach = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtNMTra = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnTKTra = new System.Windows.Forms.Button();
            this.txtTKTra = new System.Windows.Forms.TextBox();
            this.dgvDSTra = new System.Windows.Forms.DataGridView();
            this.clIdM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clngaymuon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clhanmuon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clngaytra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clnhanvien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clnguoimuon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clMSach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clTma = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clTngaymuon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clThanmuon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clTngaytra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clTnhanvien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clTnguoimuon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clTSach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSMuon)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSTra)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(1, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1008, 531);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1000, 505);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Mượn sách";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.btnTKMuon);
            this.panel3.Controls.Add(this.txtTKMuon);
            this.panel3.Controls.Add(this.dgvDSMuon);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(993, 499);
            this.panel3.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.btnNLMuon);
            this.panel4.Controls.Add(this.btnMuonSach);
            this.panel4.Controls.Add(this.dtpNgayMuon);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.dtpHanMuon);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.txtMSach);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.txtNVMuon);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.txtNMMuon);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(703, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(288, 497);
            this.panel4.TabIndex = 4;
            // 
            // btnNLMuon
            // 
            this.btnNLMuon.Location = new System.Drawing.Point(197, 298);
            this.btnNLMuon.Name = "btnNLMuon";
            this.btnNLMuon.Size = new System.Drawing.Size(75, 23);
            this.btnNLMuon.TabIndex = 18;
            this.btnNLMuon.Text = "Nhập lại";
            this.btnNLMuon.UseVisualStyleBackColor = true;
            this.btnNLMuon.Click += new System.EventHandler(this.btnNLMuon_Click);
            // 
            // btnMuonSach
            // 
            this.btnMuonSach.Location = new System.Drawing.Point(83, 298);
            this.btnMuonSach.Name = "btnMuonSach";
            this.btnMuonSach.Size = new System.Drawing.Size(75, 23);
            this.btnMuonSach.TabIndex = 19;
            this.btnMuonSach.Text = "Mượn sách";
            this.btnMuonSach.UseVisualStyleBackColor = true;
            this.btnMuonSach.Click += new System.EventHandler(this.btnMuonSach_Click);
            // 
            // dtpNgayMuon
            // 
            this.dtpNgayMuon.CustomFormat = "dd/MM/yyyy ";
            this.dtpNgayMuon.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayMuon.Location = new System.Drawing.Point(83, 219);
            this.dtpNgayMuon.Name = "dtpNgayMuon";
            this.dtpNgayMuon.Size = new System.Drawing.Size(189, 20);
            this.dtpNgayMuon.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 225);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Ngày mượn";
            // 
            // dtpHanMuon
            // 
            this.dtpHanMuon.CustomFormat = "dd/MM/yyyy";
            this.dtpHanMuon.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpHanMuon.Location = new System.Drawing.Point(83, 250);
            this.dtpHanMuon.Name = "dtpHanMuon";
            this.dtpHanMuon.Size = new System.Drawing.Size(189, 20);
            this.dtpHanMuon.TabIndex = 8;
            this.dtpHanMuon.Value = new System.DateTime(2017, 4, 23, 16, 35, 1, 0);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 257);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Hạn mượn";
            // 
            // txtMSach
            // 
            this.txtMSach.Location = new System.Drawing.Point(83, 131);
            this.txtMSach.Name = "txtMSach";
            this.txtMSach.Size = new System.Drawing.Size(189, 20);
            this.txtMSach.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 135);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Mã sách";
            // 
            // txtNVMuon
            // 
            this.txtNVMuon.Location = new System.Drawing.Point(83, 157);
            this.txtNVMuon.Name = "txtNVMuon";
            this.txtNVMuon.Size = new System.Drawing.Size(189, 20);
            this.txtNVMuon.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 161);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Nhân viên";
            // 
            // txtNMMuon
            // 
            this.txtNMMuon.Location = new System.Drawing.Point(83, 188);
            this.txtNMMuon.Name = "txtNMMuon";
            this.txtNMMuon.Size = new System.Drawing.Size(189, 20);
            this.txtNMMuon.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 193);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Người mượn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(266, 39);
            this.label2.TabIndex = 4;
            this.label2.Text = "Thông tin chi tiết";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(169, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(268, 46);
            this.label11.TabIndex = 3;
            this.label11.Text = "Quản lý mượn";
            // 
            // btnTKMuon
            // 
            this.btnTKMuon.Location = new System.Drawing.Point(499, 115);
            this.btnTKMuon.Name = "btnTKMuon";
            this.btnTKMuon.Size = new System.Drawing.Size(87, 31);
            this.btnTKMuon.TabIndex = 2;
            this.btnTKMuon.Text = "Tìm kiếm";
            this.btnTKMuon.UseVisualStyleBackColor = true;
            this.btnTKMuon.Click += new System.EventHandler(this.btnTKMuon_Click);
            // 
            // txtTKMuon
            // 
            this.txtTKMuon.Location = new System.Drawing.Point(116, 114);
            this.txtTKMuon.Multiline = true;
            this.txtTKMuon.Name = "txtTKMuon";
            this.txtTKMuon.Size = new System.Drawing.Size(359, 32);
            this.txtTKMuon.TabIndex = 1;
            // 
            // dgvDSMuon
            // 
            this.dgvDSMuon.AllowUserToAddRows = false;
            this.dgvDSMuon.AllowUserToDeleteRows = false;
            this.dgvDSMuon.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvDSMuon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSMuon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clIdM,
            this.clngaymuon,
            this.clhanmuon,
            this.clngaytra,
            this.clnhanvien,
            this.clnguoimuon,
            this.clMSach});
            this.dgvDSMuon.Location = new System.Drawing.Point(0, 190);
            this.dgvDSMuon.Name = "dgvDSMuon";
            this.dgvDSMuon.ReadOnly = true;
            this.dgvDSMuon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDSMuon.Size = new System.Drawing.Size(697, 332);
            this.dgvDSMuon.TabIndex = 0;
            this.dgvDSMuon.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDSMuon_CellClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1000, 505);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Trả sách";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnTKTra);
            this.panel1.Controls.Add(this.txtTKTra);
            this.panel1.Controls.Add(this.dgvDSTra);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(993, 499);
            this.panel1.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.btnNLTra);
            this.panel2.Controls.Add(this.btnTraSach);
            this.panel2.Controls.Add(this.dtpNgayTra);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txtNVTra);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.txtTSach);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.txtNMTra);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(703, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(288, 497);
            this.panel2.TabIndex = 4;
            // 
            // btnNLTra
            // 
            this.btnNLTra.Location = new System.Drawing.Point(206, 265);
            this.btnNLTra.Name = "btnNLTra";
            this.btnNLTra.Size = new System.Drawing.Size(75, 23);
            this.btnNLTra.TabIndex = 17;
            this.btnNLTra.Text = "Nhập lại";
            this.btnNLTra.UseVisualStyleBackColor = true;
            this.btnNLTra.Click += new System.EventHandler(this.btnNLTra_Click);
            // 
            // btnTraSach
            // 
            this.btnTraSach.Location = new System.Drawing.Point(92, 265);
            this.btnTraSach.Name = "btnTraSach";
            this.btnTraSach.Size = new System.Drawing.Size(75, 23);
            this.btnTraSach.TabIndex = 17;
            this.btnTraSach.Text = "Trả sách";
            this.btnTraSach.UseVisualStyleBackColor = true;
            this.btnTraSach.Click += new System.EventHandler(this.btnTraSach_Click);
            // 
            // dtpNgayTra
            // 
            this.dtpNgayTra.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayTra.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayTra.Location = new System.Drawing.Point(92, 217);
            this.dtpNgayTra.Name = "dtpNgayTra";
            this.dtpNgayTra.Size = new System.Drawing.Size(189, 20);
            this.dtpNgayTra.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 224);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Ngày trả";
            // 
            // txtNVTra
            // 
            this.txtNVTra.Location = new System.Drawing.Point(92, 157);
            this.txtNVTra.Name = "txtNVTra";
            this.txtNVTra.Size = new System.Drawing.Size(189, 20);
            this.txtNVTra.TabIndex = 12;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 162);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 13);
            this.label13.TabIndex = 10;
            this.label13.Text = "Nhân viên";
            // 
            // txtTSach
            // 
            this.txtTSach.Location = new System.Drawing.Point(92, 127);
            this.txtTSach.Name = "txtTSach";
            this.txtTSach.Size = new System.Drawing.Size(189, 20);
            this.txtTSach.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 131);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 13);
            this.label9.TabIndex = 10;
            this.label9.Text = "Mã sách";
            // 
            // txtNMTra
            // 
            this.txtNMTra.Location = new System.Drawing.Point(92, 187);
            this.txtNMTra.Name = "txtNMTra";
            this.txtNMTra.Size = new System.Drawing.Size(189, 20);
            this.txtNMTra.TabIndex = 13;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 193);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 13);
            this.label10.TabIndex = 11;
            this.label10.Text = "Người mượn";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(17, 35);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(266, 39);
            this.label12.TabIndex = 9;
            this.label12.Text = "Thông tin chi tiết";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(192, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(214, 46);
            this.label1.TabIndex = 3;
            this.label1.Text = "Quản lý trả";
            // 
            // btnTKTra
            // 
            this.btnTKTra.Location = new System.Drawing.Point(499, 115);
            this.btnTKTra.Name = "btnTKTra";
            this.btnTKTra.Size = new System.Drawing.Size(87, 31);
            this.btnTKTra.TabIndex = 2;
            this.btnTKTra.Text = "Tìm kiếm";
            this.btnTKTra.UseVisualStyleBackColor = true;
            this.btnTKTra.Click += new System.EventHandler(this.btnTKTra_Click);
            // 
            // txtTKTra
            // 
            this.txtTKTra.Location = new System.Drawing.Point(116, 114);
            this.txtTKTra.Multiline = true;
            this.txtTKTra.Name = "txtTKTra";
            this.txtTKTra.Size = new System.Drawing.Size(359, 32);
            this.txtTKTra.TabIndex = 1;
            // 
            // dgvDSTra
            // 
            this.dgvDSTra.AllowUserToAddRows = false;
            this.dgvDSTra.AllowUserToDeleteRows = false;
            this.dgvDSTra.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvDSTra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSTra.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clTma,
            this.clTngaymuon,
            this.clThanmuon,
            this.clTngaytra,
            this.clTnhanvien,
            this.clTnguoimuon,
            this.clTSach});
            this.dgvDSTra.Location = new System.Drawing.Point(0, 190);
            this.dgvDSTra.Name = "dgvDSTra";
            this.dgvDSTra.ReadOnly = true;
            this.dgvDSTra.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDSTra.Size = new System.Drawing.Size(697, 332);
            this.dgvDSTra.TabIndex = 0;
            this.dgvDSTra.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDSTra_CellClick);
            // 
            // clIdM
            // 
            this.clIdM.DataPropertyName = "id";
            this.clIdM.HeaderText = "Id";
            this.clIdM.Name = "clIdM";
            this.clIdM.ReadOnly = true;
            this.clIdM.Visible = false;
            // 
            // clngaymuon
            // 
            this.clngaymuon.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clngaymuon.DataPropertyName = "ngaymuon";
            this.clngaymuon.HeaderText = "Ngày mượn";
            this.clngaymuon.Name = "clngaymuon";
            this.clngaymuon.ReadOnly = true;
            // 
            // clhanmuon
            // 
            this.clhanmuon.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clhanmuon.DataPropertyName = "hanmuon";
            this.clhanmuon.HeaderText = "Hạn mượn";
            this.clhanmuon.Name = "clhanmuon";
            this.clhanmuon.ReadOnly = true;
            // 
            // clngaytra
            // 
            this.clngaytra.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clngaytra.DataPropertyName = "ngaytra";
            this.clngaytra.HeaderText = "Ngày trả";
            this.clngaytra.Name = "clngaytra";
            this.clngaytra.ReadOnly = true;
            // 
            // clnhanvien
            // 
            this.clnhanvien.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clnhanvien.DataPropertyName = "idnhansu";
            this.clnhanvien.HeaderText = "Nhân viên";
            this.clnhanvien.Name = "clnhanvien";
            this.clnhanvien.ReadOnly = true;
            // 
            // clnguoimuon
            // 
            this.clnguoimuon.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clnguoimuon.DataPropertyName = "idthethuvien";
            this.clnguoimuon.HeaderText = "Người mượn";
            this.clnguoimuon.Name = "clnguoimuon";
            this.clnguoimuon.ReadOnly = true;
            // 
            // clMSach
            // 
            this.clMSach.DataPropertyName = "idsach";
            this.clMSach.HeaderText = "Mã sách";
            this.clMSach.Name = "clMSach";
            this.clMSach.ReadOnly = true;
            // 
            // clTma
            // 
            this.clTma.DataPropertyName = "id";
            this.clTma.HeaderText = "Mã";
            this.clTma.Name = "clTma";
            this.clTma.ReadOnly = true;
            this.clTma.Visible = false;
            // 
            // clTngaymuon
            // 
            this.clTngaymuon.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clTngaymuon.DataPropertyName = "ngaymuon";
            this.clTngaymuon.HeaderText = "Ngày mượn";
            this.clTngaymuon.Name = "clTngaymuon";
            this.clTngaymuon.ReadOnly = true;
            // 
            // clThanmuon
            // 
            this.clThanmuon.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clThanmuon.DataPropertyName = "hanmuon";
            this.clThanmuon.HeaderText = "Hạn mượn";
            this.clThanmuon.Name = "clThanmuon";
            this.clThanmuon.ReadOnly = true;
            // 
            // clTngaytra
            // 
            this.clTngaytra.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clTngaytra.DataPropertyName = "ngaytra";
            this.clTngaytra.HeaderText = "Ngày trả";
            this.clTngaytra.Name = "clTngaytra";
            this.clTngaytra.ReadOnly = true;
            // 
            // clTnhanvien
            // 
            this.clTnhanvien.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clTnhanvien.DataPropertyName = "idnhansu";
            this.clTnhanvien.HeaderText = "Nhân viên";
            this.clTnhanvien.Name = "clTnhanvien";
            this.clTnhanvien.ReadOnly = true;
            // 
            // clTnguoimuon
            // 
            this.clTnguoimuon.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clTnguoimuon.DataPropertyName = "idthethuvien";
            this.clTnguoimuon.HeaderText = "Người mượn";
            this.clTnguoimuon.Name = "clTnguoimuon";
            this.clTnguoimuon.ReadOnly = true;
            // 
            // clTSach
            // 
            this.clTSach.DataPropertyName = "idsach";
            this.clTSach.HeaderText = "Mã sách";
            this.clTSach.Name = "clTSach";
            this.clTSach.ReadOnly = true;
            // 
            // fMuonTraSach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1009, 535);
            this.Controls.Add(this.tabControl1);
            this.Name = "fMuonTraSach";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mượn / trả  sách";
            this.Load += new System.EventHandler(this.fMuonTraSach_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSMuon)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSTra)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnTKMuon;
        private System.Windows.Forms.TextBox txtTKMuon;
        private System.Windows.Forms.DataGridView dgvDSMuon;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnTKTra;
        private System.Windows.Forms.TextBox txtTKTra;
        private System.Windows.Forms.DataGridView dgvDSTra;
        private System.Windows.Forms.Button btnNLMuon;
        private System.Windows.Forms.Button btnMuonSach;
        private System.Windows.Forms.DateTimePicker dtpNgayMuon;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtpHanMuon;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNVMuon;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNMMuon;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnNLTra;
        private System.Windows.Forms.Button btnTraSach;
        private System.Windows.Forms.DateTimePicker dtpNgayTra;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtTSach;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtNMTra;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtMSach;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtNVTra;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridViewTextBoxColumn clIdM;
        private System.Windows.Forms.DataGridViewTextBoxColumn clngaymuon;
        private System.Windows.Forms.DataGridViewTextBoxColumn clhanmuon;
        private System.Windows.Forms.DataGridViewTextBoxColumn clngaytra;
        private System.Windows.Forms.DataGridViewTextBoxColumn clnhanvien;
        private System.Windows.Forms.DataGridViewTextBoxColumn clnguoimuon;
        private System.Windows.Forms.DataGridViewTextBoxColumn clMSach;
        private System.Windows.Forms.DataGridViewTextBoxColumn clTma;
        private System.Windows.Forms.DataGridViewTextBoxColumn clTngaymuon;
        private System.Windows.Forms.DataGridViewTextBoxColumn clThanmuon;
        private System.Windows.Forms.DataGridViewTextBoxColumn clTngaytra;
        private System.Windows.Forms.DataGridViewTextBoxColumn clTnhanvien;
        private System.Windows.Forms.DataGridViewTextBoxColumn clTnguoimuon;
        private System.Windows.Forms.DataGridViewTextBoxColumn clTSach;
    }
}