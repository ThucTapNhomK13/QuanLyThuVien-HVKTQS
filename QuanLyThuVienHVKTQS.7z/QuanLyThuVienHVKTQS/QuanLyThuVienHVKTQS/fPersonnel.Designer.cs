﻿namespace QuanLyThuVienHVKTQS
{
    partial class fPersonnel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cmtDGV = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ImenuDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.ImenuShowInfomation = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.ckbQLNV = new System.Windows.Forms.CheckBox();
            this.dtpNSNV = new System.Windows.Forms.DateTimePicker();
            this.rdbNuNV = new System.Windows.Forms.RadioButton();
            this.rdbNamNV = new System.Windows.Forms.RadioButton();
            this.btnXoaNV = new System.Windows.Forms.Button();
            this.btnNhapLaiNV = new System.Windows.Forms.Button();
            this.btnSuaNV = new System.Windows.Forms.Button();
            this.btnGhiNV = new System.Windows.Forms.Button();
            this.txtMKNV = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTKNV = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtHoTenNV = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAnhNV = new System.Windows.Forms.Button();
            this.picNV = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.btnTKNhanVien = new System.Windows.Forms.Button();
            this.txtTKNhanVien = new System.Windows.Forms.TextBox();
            this.dgvDSNV = new System.Windows.Forms.DataGridView();
            this.clMa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clHoTen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clNgaySinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clGioiTinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clTaiKhoan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clMatKhau = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clQuanLy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clAnh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cmtDGV.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picNV)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSNV)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmtDGV
            // 
            this.cmtDGV.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ImenuDelete,
            this.ImenuShowInfomation});
            this.cmtDGV.Name = "cmtDGV";
            this.cmtDGV.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.cmtDGV.Size = new System.Drawing.Size(151, 48);
            // 
            // ImenuDelete
            // 
            this.ImenuDelete.Name = "ImenuDelete";
            this.ImenuDelete.Size = new System.Drawing.Size(150, 22);
            this.ImenuDelete.Text = "Xóa";
            // 
            // ImenuShowInfomation
            // 
            this.ImenuShowInfomation.Name = "ImenuShowInfomation";
            this.ImenuShowInfomation.Size = new System.Drawing.Size(150, 22);
            this.ImenuShowInfomation.Text = "Xem thông tin";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(996, 530);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Nhân viên";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.ckbQLNV);
            this.panel2.Controls.Add(this.dtpNSNV);
            this.panel2.Controls.Add(this.rdbNuNV);
            this.panel2.Controls.Add(this.rdbNamNV);
            this.panel2.Controls.Add(this.btnXoaNV);
            this.panel2.Controls.Add(this.btnNhapLaiNV);
            this.panel2.Controls.Add(this.btnSuaNV);
            this.panel2.Controls.Add(this.btnGhiNV);
            this.panel2.Controls.Add(this.txtMKNV);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.txtTKNV);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txtHoTenNV);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.btnAnhNV);
            this.panel2.Controls.Add(this.picNV);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(708, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(285, 524);
            this.panel2.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(13, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(266, 39);
            this.label6.TabIndex = 9;
            this.label6.Text = "Thông tin chi tiết";
            // 
            // ckbQLNV
            // 
            this.ckbQLNV.AutoSize = true;
            this.ckbQLNV.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckbQLNV.Location = new System.Drawing.Point(93, 420);
            this.ckbQLNV.Name = "ckbQLNV";
            this.ckbQLNV.Size = new System.Drawing.Size(67, 19);
            this.ckbQLNV.TabIndex = 8;
            this.ckbQLNV.Text = "Quản lý";
            this.ckbQLNV.UseVisualStyleBackColor = true;
            // 
            // dtpNSNV
            // 
            this.dtpNSNV.CustomFormat = "MM/dd/yyyy";
            this.dtpNSNV.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNSNV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNSNV.Location = new System.Drawing.Point(93, 313);
            this.dtpNSNV.Name = "dtpNSNV";
            this.dtpNSNV.Size = new System.Drawing.Size(170, 23);
            this.dtpNSNV.TabIndex = 7;
            // 
            // rdbNuNV
            // 
            this.rdbNuNV.AutoSize = true;
            this.rdbNuNV.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbNuNV.Location = new System.Drawing.Point(157, 342);
            this.rdbNuNV.Name = "rdbNuNV";
            this.rdbNuNV.Size = new System.Drawing.Size(41, 19);
            this.rdbNuNV.TabIndex = 6;
            this.rdbNuNV.Text = "Nữ";
            this.rdbNuNV.UseVisualStyleBackColor = true;
            // 
            // rdbNamNV
            // 
            this.rdbNamNV.AutoSize = true;
            this.rdbNamNV.Checked = true;
            this.rdbNamNV.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbNamNV.Location = new System.Drawing.Point(93, 342);
            this.rdbNamNV.Name = "rdbNamNV";
            this.rdbNamNV.Size = new System.Drawing.Size(51, 19);
            this.rdbNamNV.TabIndex = 5;
            this.rdbNamNV.TabStop = true;
            this.rdbNamNV.Text = "Nam";
            this.rdbNamNV.UseVisualStyleBackColor = true;
            // 
            // btnXoaNV
            // 
            this.btnXoaNV.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaNV.Location = new System.Drawing.Point(208, 468);
            this.btnXoaNV.Name = "btnXoaNV";
            this.btnXoaNV.Size = new System.Drawing.Size(51, 23);
            this.btnXoaNV.TabIndex = 4;
            this.btnXoaNV.Text = "Xóa";
            this.btnXoaNV.UseVisualStyleBackColor = true;
            this.btnXoaNV.Click += new System.EventHandler(this.btnXoaNV_Click);
            // 
            // btnNhapLaiNV
            // 
            this.btnNhapLaiNV.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhapLaiNV.Location = new System.Drawing.Point(142, 468);
            this.btnNhapLaiNV.Name = "btnNhapLaiNV";
            this.btnNhapLaiNV.Size = new System.Drawing.Size(60, 23);
            this.btnNhapLaiNV.TabIndex = 4;
            this.btnNhapLaiNV.Text = "Nhập lại";
            this.btnNhapLaiNV.UseVisualStyleBackColor = true;
            this.btnNhapLaiNV.Click += new System.EventHandler(this.btnNhapLaiNV_Click);
            // 
            // btnSuaNV
            // 
            this.btnSuaNV.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaNV.Location = new System.Drawing.Point(87, 468);
            this.btnSuaNV.Name = "btnSuaNV";
            this.btnSuaNV.Size = new System.Drawing.Size(49, 23);
            this.btnSuaNV.TabIndex = 4;
            this.btnSuaNV.Text = "Sửa";
            this.btnSuaNV.UseVisualStyleBackColor = true;
            this.btnSuaNV.Click += new System.EventHandler(this.btnSuaNV_Click);
            // 
            // btnGhiNV
            // 
            this.btnGhiNV.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGhiNV.Location = new System.Drawing.Point(32, 468);
            this.btnGhiNV.Name = "btnGhiNV";
            this.btnGhiNV.Size = new System.Drawing.Size(49, 23);
            this.btnGhiNV.TabIndex = 4;
            this.btnGhiNV.Text = "Ghi";
            this.btnGhiNV.UseVisualStyleBackColor = true;
            this.btnGhiNV.Click += new System.EventHandler(this.btnGhiNV_Click);
            // 
            // txtMKNV
            // 
            this.txtMKNV.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMKNV.Location = new System.Drawing.Point(93, 393);
            this.txtMKNV.Name = "txtMKNV";
            this.txtMKNV.Size = new System.Drawing.Size(170, 23);
            this.txtMKNV.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(28, 393);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "Mật khẩu";
            // 
            // txtTKNV
            // 
            this.txtTKNV.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTKNV.Location = new System.Drawing.Point(93, 367);
            this.txtTKNV.Name = "txtTKNV";
            this.txtTKNV.Size = new System.Drawing.Size(170, 23);
            this.txtTKNV.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(28, 367);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 15);
            this.label4.TabIndex = 2;
            this.label4.Text = "Tài khoản";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(28, 341);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Giới tính";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 315);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ngày sinh";
            // 
            // txtHoTenNV
            // 
            this.txtHoTenNV.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHoTenNV.Location = new System.Drawing.Point(93, 286);
            this.txtHoTenNV.Name = "txtHoTenNV";
            this.txtHoTenNV.Size = new System.Drawing.Size(170, 23);
            this.txtHoTenNV.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 289);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Họ tên";
            // 
            // btnAnhNV
            // 
            this.btnAnhNV.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnhNV.Location = new System.Drawing.Point(93, 240);
            this.btnAnhNV.Name = "btnAnhNV";
            this.btnAnhNV.Size = new System.Drawing.Size(134, 23);
            this.btnAnhNV.TabIndex = 1;
            this.btnAnhNV.Text = "Chọn ảnh";
            this.btnAnhNV.UseVisualStyleBackColor = true;
            this.btnAnhNV.Click += new System.EventHandler(this.btnAnhNV_Click);
            // 
            // picNV
            // 
            this.picNV.BackColor = System.Drawing.Color.WhiteSmoke;
            this.picNV.Location = new System.Drawing.Point(93, 78);
            this.picNV.Name = "picNV";
            this.picNV.Size = new System.Drawing.Size(134, 156);
            this.picNV.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picNV.TabIndex = 0;
            this.picNV.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.btnTKNhanVien);
            this.panel1.Controls.Add(this.txtTKNhanVien);
            this.panel1.Controls.Add(this.dgvDSNV);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(699, 524);
            this.panel1.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(207, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(309, 46);
            this.label7.TabIndex = 10;
            this.label7.Text = "Quản lý nhân sự";
            // 
            // btnTKNhanVien
            // 
            this.btnTKNhanVien.Location = new System.Drawing.Point(556, 140);
            this.btnTKNhanVien.Name = "btnTKNhanVien";
            this.btnTKNhanVien.Size = new System.Drawing.Size(87, 31);
            this.btnTKNhanVien.TabIndex = 2;
            this.btnTKNhanVien.Text = "Tìm kiếm";
            this.btnTKNhanVien.UseVisualStyleBackColor = true;
            this.btnTKNhanVien.Click += new System.EventHandler(this.btnTKNhanVien_Click);
            // 
            // txtTKNhanVien
            // 
            this.txtTKNhanVien.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTKNhanVien.Location = new System.Drawing.Point(168, 140);
            this.txtTKNhanVien.Name = "txtTKNhanVien";
            this.txtTKNhanVien.Size = new System.Drawing.Size(359, 30);
            this.txtTKNhanVien.TabIndex = 1;
            // 
            // dgvDSNV
            // 
            this.dgvDSNV.AllowUserToAddRows = false;
            this.dgvDSNV.AllowUserToDeleteRows = false;
            this.dgvDSNV.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvDSNV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSNV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clMa,
            this.clHoTen,
            this.clNgaySinh,
            this.clGioiTinh,
            this.clTaiKhoan,
            this.clMatKhau,
            this.clQuanLy,
            this.clAnh});
            this.dgvDSNV.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvDSNV.Location = new System.Drawing.Point(0, 192);
            this.dgvDSNV.Name = "dgvDSNV";
            this.dgvDSNV.ReadOnly = true;
            this.dgvDSNV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDSNV.Size = new System.Drawing.Size(697, 330);
            this.dgvDSNV.TabIndex = 0;
            this.dgvDSNV.SelectionChanged += new System.EventHandler(this.dgvDSNV_SelectionChanged);
            // 
            // clMa
            // 
            this.clMa.DataPropertyName = "id";
            this.clMa.HeaderText = "Mã";
            this.clMa.Name = "clMa";
            this.clMa.ReadOnly = true;
            this.clMa.Visible = false;
            // 
            // clHoTen
            // 
            this.clHoTen.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clHoTen.DataPropertyName = "ten";
            this.clHoTen.HeaderText = "Họ và tên";
            this.clHoTen.Name = "clHoTen";
            this.clHoTen.ReadOnly = true;
            // 
            // clNgaySinh
            // 
            this.clNgaySinh.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clNgaySinh.DataPropertyName = "ngaysinh";
            this.clNgaySinh.HeaderText = "Ngày sinh";
            this.clNgaySinh.Name = "clNgaySinh";
            this.clNgaySinh.ReadOnly = true;
            // 
            // clGioiTinh
            // 
            this.clGioiTinh.DataPropertyName = "gioitinh";
            this.clGioiTinh.HeaderText = "Giói tính";
            this.clGioiTinh.Name = "clGioiTinh";
            this.clGioiTinh.ReadOnly = true;
            // 
            // clTaiKhoan
            // 
            this.clTaiKhoan.DataPropertyName = "taikhoan";
            this.clTaiKhoan.HeaderText = "Tài khoản";
            this.clTaiKhoan.Name = "clTaiKhoan";
            this.clTaiKhoan.ReadOnly = true;
            // 
            // clMatKhau
            // 
            this.clMatKhau.DataPropertyName = "matkhau";
            this.clMatKhau.HeaderText = "Mật khẩu";
            this.clMatKhau.Name = "clMatKhau";
            this.clMatKhau.ReadOnly = true;
            // 
            // clQuanLy
            // 
            this.clQuanLy.DataPropertyName = "quanly";
            this.clQuanLy.HeaderText = "Quản lý";
            this.clQuanLy.Name = "clQuanLy";
            this.clQuanLy.ReadOnly = true;
            // 
            // clAnh
            // 
            this.clAnh.DataPropertyName = "anhdaidien";
            this.clAnh.HeaderText = "Ảnh đại diện";
            this.clAnh.Name = "clAnh";
            this.clAnh.ReadOnly = true;
            this.clAnh.Visible = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1004, 556);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(996, 530);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Kho chứa";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // fPersonnel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1004, 556);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "fPersonnel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "fNhanSu";
            this.Load += new System.EventHandler(this.fPersonnel_Load);
            this.cmtDGV.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picNV)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSNV)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ContextMenuStrip cmtDGV;
        private System.Windows.Forms.ToolStripMenuItem ImenuDelete;
        private System.Windows.Forms.ToolStripMenuItem ImenuShowInfomation;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Button btnXoaNV;
        private System.Windows.Forms.Button btnNhapLaiNV;
        private System.Windows.Forms.Button btnSuaNV;
        private System.Windows.Forms.Button btnGhiNV;
        private System.Windows.Forms.TextBox txtMKNV;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTKNV;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtHoTenNV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAnhNV;
        private System.Windows.Forms.PictureBox picNV;
        private System.Windows.Forms.Button btnTKNhanVien;
        private System.Windows.Forms.TextBox txtTKNhanVien;
        private System.Windows.Forms.DataGridView dgvDSNV;
        private System.Windows.Forms.CheckBox ckbQLNV;
        private System.Windows.Forms.DateTimePicker dtpNSNV;
        private System.Windows.Forms.RadioButton rdbNuNV;
        private System.Windows.Forms.RadioButton rdbNamNV;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridViewTextBoxColumn clMa;
        private System.Windows.Forms.DataGridViewTextBoxColumn clHoTen;
        private System.Windows.Forms.DataGridViewTextBoxColumn clNgaySinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn clGioiTinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn clTaiKhoan;
        private System.Windows.Forms.DataGridViewTextBoxColumn clMatKhau;
        private System.Windows.Forms.DataGridViewTextBoxColumn clQuanLy;
        private System.Windows.Forms.DataGridViewTextBoxColumn clAnh;
    }
}